import React from 'react';
import { View, Text } from 'react-native';

export default function SignIn() {
 return (
   <View>
       <Text>SignIn</Text>
   </View>
  );
}
import React from 'react';
import { View, Text } from 'react-native';
import firebase from './src/services/firebaseConnection';

export default function App() {
 return (
   <View>
     <Text>123123</Text>
   </View>
  );
}
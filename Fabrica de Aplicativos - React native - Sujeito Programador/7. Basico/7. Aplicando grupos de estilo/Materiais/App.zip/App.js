import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

function App(){
  
  return(
   <View style={styles.area}>

     <Text style={[styles.titulo, styles.textoAlinhado]}> Matheus </Text>

     <Text style={styles.titulo}> Sujeito Programador </Text>

     <Text style={[styles.subTitulo, styles.textoAlinhado]} >Sou um texto 3</Text>

   </View> 
  );
}

const styles = StyleSheet.create({
  area:{
   marginTop: 50
  },
  titulo:{
    fontSize: 20,
    color: '#FF0000',
  },
  subTitulo:{
    color: '#00FF00',
    fontSize: 17,
    marginTop: 15
  },
  textoAlinhado:{
    textAlign: 'center'
  }
});

export default App;

import React from 'react';
import { View, Text, } from 'react-native';

function App(){
  
  return(
   <View style={{ flex:1,  backgroundColor: '#121212' }}>

     <View style={{ height: 65, backgroundColor: '#121212'  }}>

     </View>

     <View style={{ flex:1, backgroundColor: '#DDD'  }}>
       <Text> SOU UM TEXTO </Text>
     </View>

     <View style={{ height: 65, backgroundColor: '#121212'  }}></View>

   </View> 
  );
}



export default App;

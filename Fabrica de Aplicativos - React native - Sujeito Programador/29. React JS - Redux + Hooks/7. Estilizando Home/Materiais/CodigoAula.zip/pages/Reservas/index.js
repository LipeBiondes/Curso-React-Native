import React from 'react';

export default function Reservas() {
 return (
   <div>
     <h1>Reservas</h1>
   </div>
 );
}
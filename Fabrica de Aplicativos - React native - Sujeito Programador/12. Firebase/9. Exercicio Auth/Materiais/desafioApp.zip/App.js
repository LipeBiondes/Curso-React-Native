import React from 'react';
import Routes from './src/routes';
import { LogBox } from 'react-native';

LogBox.ignoreAllLogs(true);


export default function App() {
 return (
   <Routes/>
  );
}
import React, { useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';

import Slider from '@react-native-community/slider';

export default function App() {
  const [valor, setValor] = useState(50);

 return (
  <View style={styles.container}>

    <Slider
    minimumValue={0}
    maximumValue={100}
    value={valor}
    onValueChange={ (valoSelecionado) => setValor(valoSelecionado) }
    minimumTrackTintColor="#000FFF"
    maximumTrackTintColor="#FF0000"
    thumbTintColor="#FF0000"
    />

   <Text style={{ textAlign: 'center', fontSize: 25 }}>Você tem: {valor.toFixed(0)} kg </Text>
    
  </View>
  );
}

const styles = StyleSheet.create({
  container:{
    flex:1,
    marginTop: 35
  },
})


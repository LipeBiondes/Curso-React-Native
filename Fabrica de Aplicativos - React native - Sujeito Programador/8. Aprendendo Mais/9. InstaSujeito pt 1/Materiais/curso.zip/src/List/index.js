import React from 'react';
import {View, Text} from 'react-native';

export default function List(){
  return(
    <View>
      <Text>LISTA FEED</Text>
    </View>
  );
}
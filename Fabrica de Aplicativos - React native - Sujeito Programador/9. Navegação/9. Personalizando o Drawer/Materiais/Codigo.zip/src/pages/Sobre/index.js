import React from 'react';
import { View, Text} from 'react-native';

export default function Sobre() {
 return (
   <View>
     <Text>Sobre</Text>
   </View>
  );
}
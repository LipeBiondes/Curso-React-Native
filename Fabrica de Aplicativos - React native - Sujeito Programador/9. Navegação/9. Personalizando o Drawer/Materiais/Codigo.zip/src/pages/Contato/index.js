import React from 'react';
import { View, Text} from 'react-native';

export default function Contato() {
 return (
   <View>
     <Text>Contato</Text>
     <Text>Contato</Text>
     <Text>Contato</Text>
     <Text>Contato</Text>
     <Text>Contato</Text>
   </View>
  );
}
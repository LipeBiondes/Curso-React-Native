
import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View,} from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import Pin from './src/Pin';
/*
SP: -23.5492243   -46.5813785
DF: -15.8080374  -47.8750231
CG: -20.4695225 -54.6016767
*/
export default class App extends Component {
  constructor(props){
    super(props);
    this.state = {
      region:{
        latitude:-15.8080374,
        longitude:-47.8750231,
        latitudeDelta:0.0922,
        longitudeDelta:0.0421       
      },
      markers:[
        {key: 0, aviso:'Cuidado', coords:{latitude:-15.8080374,longitude:-47.8750231}, pinColor:'red' },
        {key: 1, aviso:'Tranquilo', coords:{latitude:-15.8380374,longitude:-47.8850231}, pinColor:'green' },
        {key: 2, aviso:'Cuidado', coords:{latitude:-15.8480374,longitude:-47.8950231}, pinColor:'red' }
      ]
    };

  }

  render() {
    const {region, markers} = this.state;

    return (
      <View style={styles.container}>
        <Text>{region.latitude} | {region.longitude}</Text>

        <MapView
          style={styles.mapa}
          region={region}>

           {
             markers.map((marker)=>{
             return(
                <Marker key={marker.key} coordinate={marker.coords}>
                  <Pin aviso={marker.aviso} corFundo={marker.pinColor} />
                </Marker>

             );
           })
           }       

        </MapView>

      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  mapa:{
    width:'100%',
    height:550,
    marginTop: 15
  }
});

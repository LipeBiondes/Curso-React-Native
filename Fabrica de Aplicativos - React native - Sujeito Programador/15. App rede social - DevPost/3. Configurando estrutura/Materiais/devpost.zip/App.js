import React from 'react';
import { View, Text } from 'react-native';

export default function App() {
 return (
   <View>
     <Text>DevPost</Text>
   </View>
  );
}
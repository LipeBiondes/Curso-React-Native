import React, { useLayoutEffect, useState } from 'react';
import { useNavigation } from '@react-navigation/native';

import { View, Text } from 'react-native';

export default function PostsUser({ route }) {
  const navigation = useNavigation();
  const [title, setTitle] = useState(route.params.title);

  useLayoutEffect(()=> {
    navigation.setOptions({
      title: title === '' ? '' : title
    });

  }, [navigation, title]);

 return (
   <View>
       <Text> POSTS DO USUARIO  UNICO </Text>
   </View>
  );
}
import React from 'react';
import { View, Text } from 'react-native';

export default function PostsUser() {
 return (
   <View>
       <Text>Pagina PostsUser</Text>
   </View>
  );
}
import React from 'react';
import { View, Text } from 'react-native';

export default function NewPost() {
 return (
   <View>
       <Text>Pagina NewPost</Text>
   </View>
  );
}
import React from 'react';
import { View, Text } from 'react-native';

export default function Login() {
 return (
   <View>
       <Text>Pagina Login</Text>
   </View>
  );
}
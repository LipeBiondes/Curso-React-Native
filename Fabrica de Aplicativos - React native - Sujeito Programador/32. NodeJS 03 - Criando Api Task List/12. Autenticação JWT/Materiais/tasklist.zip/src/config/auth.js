export default {
  secret: '6e550a642f3d5f2d2a364ab96697080f',
  expiresIn: '7d',
};
